<?php
header("location:http://keltaking.co/KeltaAttendance/");
	session_start();
	session_unset();
	session_destroy();
	
?>