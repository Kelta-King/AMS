<?php

$servername = "localhost";
$password = "2001kushang";
$username = "keltakin_kelta";
$database = "keltakin_attendance_portal";

$conn = new mysqli($servername, $username, $password, $database);

if($conn->connect_error)
{
    die("something went wrong:$conn->connect_error");
}


?>