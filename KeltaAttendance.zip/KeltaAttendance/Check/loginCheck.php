<?php
session_start();

//if loginprocess is not started then user cannot access this page
if(isset($_SESSION['login_process']) && $_SESSION['login_process'] == "start"){
	function test_input($data) 
	{
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$opt = [
		'cost' => 12
	];

	if(isset($_POST['RollNo']) && isset($_POST['Pass'])){
		
		$RollNo = test_input($_POST['RollNo']);
		$Pass = test_input($_POST['Pass']);

		//admin has RollNo 111111 and password admin1
		//settype($RollNo, 'integer');
		$query1 = "SELECT RollNo, password, account_type FROM `users` WHERE RollNo = $RollNo";

		// please note %d in the format string, using %s would be meaningless
		$query1 = sprintf("SELECT RollNo, password, account_type FROM `users` WHERE RollNo= %d", $RollNo);

		require_once('../database/dbconnect.php');
		if($data = $conn->query($query1)){
			if($data->num_rows > 0){
				
				while($result = $data->fetch_assoc()){
					$dbpass = $result['password'];
					
					if(password_verify($Pass, $dbpass)){
						$_SESSION['login_user'] = $result['RollNo']."&".$result['account_type'];
					}
					else{
						echo "incorrect password";
					}
				}	
			}
			else{
				echo "incorrect UserId or Password";
			}
			
		}
		else{
			echo "something went wrong";
		}
		
		$conn->close();
	}
	else{
		header("location:https://keltaking.co/KeltaAttendance/");
	}

}
else{
	echo "something went wrong";
}
	
?>