<?php
session_start();

require_once("../Commen/header.php");

if(isset($_SESSION['login_user']) && isset($_POST['date']) && isset($_POST['date']) && isset($_POST['sub'])){
	echo "<div class='w3-padding-32'></div><div class='w3-center w3-xxlarge'>";
	//echo $_POST['sub'];
	$atten = array();
	$arr = array();
	$date = $_POST['date'];
	$sub_id = $_POST['sub'];
	$query1 = "SELECT u_id FROM `users` WHERE account_type = 'student'";
	require_once('../database/dbconnect.php');
	$i=0;
	if($data = $conn->query($query1)){
		while($rslt = $data->fetch_assoc()){
			$index = (string)$rslt['u_id'];
			$arr[$i] = $index;
			$atten[$i] = $_POST[$index];
			$i++;
		}
	}
	else{
		echo "something went wrong";
	}
	
	$i=0;
	$b=0;
	while($i<sizeof($arr))
	{
		$PorA = $atten[$i];
		$stu_id = $arr[$i];
		$query2 = "INSERT INTO attendance (sub_id, a_date, stu_id, PorA) VALUES ($sub_id, '$date', $stu_id, '$PorA')";
		if($conn->query($query2)){
			echo "attendance inserted for id = $stu_id <br>";
		}
		else{
			$b++;
		}
		
		
		$i++;
	}
	
	if($b > 0){
		echo "Someone already submitted this attendence";
	}
	echo "</div>";
	$url = $_SERVER['HTTP_REFERER'];
	echo "<center><a href='$url' class='w3-xlarge'>Back</a></center>";
	$conn->close();
	
}
else{
	echo "something went wrong";
}

require_once("../Commen/footer.php");
?>