let addrelation = (index) =>{
	let c = confirm("Do you really want to add this relation?");
	if(c){
		
		let s_id = document.getElementById('selectSub').value;
		let t_id = document.getElementById('selectTeacher').value;
		if(s_id == "" || t_id == ""){
			alert("fill the data");
			return;
		}
		let str = "s_id="+s_id+"&t_id="+t_id;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader5');
		xhttp.onreadystatechange = function() {
			loader.style.display = "block";
			if(this.readyState == 4 && this.status == 200){
				
				alert(this.responseText);
				loader.style.display = "none";
				location.reload();
			}
		}
		xhttp.open("POST", "./Commen/addRelation", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send(str);
		
	}
}

let remove = (index) =>{
	let c = confirm("Do you really want to remove this use?");
	if(c){
		
		let str = "u_id="+index;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader');
		xhttp.onreadystatechange = function() {
			loader.style.display = "block";
			if(this.readyState == 4 && this.status == 200){
				
				alert(this.responseText);
				loader.style.display = "none";
				location.reload();
			}
		}
		xhttp.open("POST", "./Commen/remove", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send(str);
		
	}
}

let removeSub = (index) =>{
	let c = confirm("Do you really want to remove this use?");
	if(c){
		
		let str = "s_id="+index;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader4');
		xhttp.onreadystatechange = function() {
			loader.style.display = "block";
			if(this.readyState == 4 && this.status == 200){
				
				alert(this.responseText);
				loader.style.display = "none";
				location.reload();
			}
		}
		xhttp.open("POST", "./Commen/removeSub", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send(str);
		
	}
}

let adduser = () =>{
	
	let c = confirm("Do you really want to add this use?");
	if(c){
	
		let firstname = add.fname.value;
		let lastname = add.lname.value;
		let RollNo = add.RollNo.value;
		let acc_type = add.acc_type.value;
		
		if(firstname == "" || lastname == "" || RollNo == "" || acc_type == ""){
			alert("fill all the values");
			return;
		}
		
		if(RollNo.lenght < 4){
			alert("RollNo must be atleast more than 4 chars");
			return;
		}
		
		let str = "firstname="+firstname+"&lastname="+lastname +"&acc_type="+acc_type+"&RollNo="+RollNo;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader2');
		xhttp.onreadystatechange = function() {
			loader.style.display = "block";
			if(this.readyState == 4 && this.status == 200){
				
				alert(this.responseText);
				loader.style.display = "none";
				location.reload();
			}
		}
		xhttp.open("POST", "./Commen/addUser", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send(str);
	}
}

let addsubject = () =>{
	
	let c = confirm("Do you really want to add this subject?");
	if(c){
	
		let sub = addSub.subject.value;
		
		if(sub == ""){
			alert("fill the field");
			return;
		}
		
		let str = "subject="+sub;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader3');
		xhttp.onreadystatechange = function() {
			loader.style.display = "block";
			if(this.readyState == 4 && this.status == 200){
				
				alert(this.responseText);
				loader.style.display = "none";
				location.reload();
			}
		}
		xhttp.open("POST", "./Commen/addSub", true);
		xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xhttp.send(str);
	}
}