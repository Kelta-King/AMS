let login=()=>{
		let form = document.getElementById('login');
		let RollNo = form.RollNo.value;
		let Pass = form.password.value;
		
		//to check all fields are mendatory error
		if(RollNo == "" || Pass == ""){
			alert("Fill all the fields");
			document.getElementById('error').innerHTML = "Fill all the fields";
			return;
		}
		//password must be more that 4 letters
		if(Pass.length < 4){
			alert("Please, enter valid data");
			document.getElementById('error').innerHTML = "Please, enter valid data";
			form.password.focus();
			return;
		}
		
		//RollNo must be more than or equal to 4
		if(RollNo.length < 4){
			alert("Please, enter valid data");
			document.getElementById('error').innerHTML = "Please, enter valid data";
			form.RollNo.focus();
			return;
		}
		
		//to check whether a user is trying to inject sql quries in RollNo field, basic protection
		if(RollNo.includes("$") || RollNo.includes("&") || RollNo.includes("=") || RollNo.includes("*") || RollNo.includes("`")){
			alert("Please, enter valid data");
			document.getElementById('error').innerHTML = "Please, enter valid data";
			form.RollNo.focus();
			return;
		}
		
		//to check whether a user is trying to inject sql quries in password field, basic protection, further in php
		if(Pass.includes("$") || Pass.includes("&") || Pass.includes("=") || Pass.includes("*") || Pass.includes("`")){
			alert("Please, enter valid data");
			document.getElementById('error').innerHTML = "Please, enter valid data";
			form.password.focus();
			return;
		}
		
		let str = "RollNo="+RollNo+"&Pass="+Pass;
		let xhttp = new XMLHttpRequest();
		let loader = document.getElementById('loader');
			xhttp.onreadystatechange = function() {
				loader.style.display = "block";
				if(this.readyState == 4 && this.status == 200){
					document.getElementById('error').innerHTML = this.responseText;
					loader.style.display = "none";
					if(this.responseText == ""){
						form.action = "login";
						form.method = "post";
						form.submit();
					}
				}
			}
			xhttp.open("POST", "Check/loginCheck", true);
		  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		  xhttp.send(str);
		
	}