let openCity = (cityName) => {
  let i;
  let x = document.getElementsByClassName("subject");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  document.getElementById(cityName).style.display = "block";  
}

let convertSheet = (name, type, fn, dl) => {
	var elt = document.getElementById(name);
	var wb = XLSX.utils.table_to_book(elt, {sheet:name});
	return dl ?
      XLSX.write(wb, {bookType:type, bookSST:true, type: 'base64'}) :
      XLSX.writeFile(wb, fn || ('AttendenceSheet'+name+'.' + (type || 'xlsx')));
}


let addAtten = () => {
	let c = confirm("Do you really want to submit the attendence?");
	if(!c){
		document.getElementById('addAttendence').action = "";
		return;
	}
	document.getElementById('addAttendence').action = "./Action/addAttendence";
}