<footer class="w3-blue w3-padding-32 w3-center w3-xxlarge">
Thanks for visiting <a href="https://keltaking.co/">KeltaKing</a> Productions
</footer>