<?php
	session_start();

	if(isset($_SESSION['login_user']))
	{
		$s_id = $_REQUEST['s_id'];
		
		$query = "DELETE FROM `subjects` WHERE s_id = $s_id";
		require_once("../database/dbconnect.php");
		if($conn->query($query)){
			echo "data deleted successfully";
		}
		else
		{
			echo "Something went wrong";
		}
		
		$conn->close();
	}
	else{
		echo "Something went wrong1";
	}
?>