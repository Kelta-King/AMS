<?php
session_start();

if(isset($_SESSION['login_user'])){
	
	$s_id = $_REQUEST['s_id'];
	$t_id = $_REQUEST['t_id'];
	
	$query = "INSERT INTO sub_teacher (t_id, s_id) VALUES ($t_id, $s_id)";
	
	require_once("../database/dbconnect.php");
		
	if($conn->query($query)){
		echo "New Relation successfully inserted";
	}
	else{
		echo "This relation already exist";
	}
	
	$conn->close();
}
else{
	echo "something went wrong";
}
	

?>