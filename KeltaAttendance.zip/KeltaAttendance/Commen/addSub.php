<?php
session_start();

if(isset($_SESSION['login_user'])){
	
	$sub = $_REQUEST['subject'];
	$query = "INSERT INTO subjects (s_name) VALUES ('$sub') ";
	
	require_once("../database/dbconnect.php");
		
	if($conn->query($query)){
		echo "New subject successfully inserted";
	}
	else{
		echo "something went wrong";
	}
	$conn->close();
}
else{
	echo "something went wrong";
}
	

?>