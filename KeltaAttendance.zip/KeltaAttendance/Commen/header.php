<!DOCTYPE html>
<html>
	<head>
		<title>home | Kelta Attendance Portal</title>
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="kel-CSS/kel.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href='https://fonts.googleapis.com/css?family=Aleo' rel='stylesheet'>
		
		<style>
			.loader {
			  border: 5px solid #f3f3f3;
			  border-radius: 50%;
			  border-top: 5px solid #3498db;
			  width: 30px;
			  height: 30px;
			  -webkit-animation: spin 1s linear infinite; 
			  animation: spin 1s linear infinite;
			}

			@-webkit-keyframes spin {
			  0% { -webkit-transform: rotate(0deg); }
			  100% { -webkit-transform: rotate(360deg); }
			}

			@keyframes spin {
			  0% { transform: rotate(0deg); }
			  100% { transform: rotate(360deg); }
			}
		</style>
	</head>
<body class="w3-light-gray">


<header class="w3-blue w3-top w3-bar">
	<h1 class="w3-left w3-bar-item w3-xlarge w3-margin-left">Kelta Attendance Portal</h1>
	<a href="https://keltaking.co/KeltaAttendance/logout"><button class="kel-hover w3-button w3-white w3-hover-white w3-right w3-bar-item w3-margin">Logout</button></a>
</header>
<div class="w3-padding-32"></div>