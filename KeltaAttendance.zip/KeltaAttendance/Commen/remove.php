<?php
	session_start();

	if(isset($_SESSION['login_user']))
	{
		$u_id = $_REQUEST['u_id'];
		
		$query = "DELETE FROM `users` WHERE u_id = $u_id";
		require_once("../database/dbconnect.php");
		if($conn->query($query)){
			echo "data deleted successfully";
		}
		else
		{
			echo "Something went wrong";
		}
		
		$conn->close();
	}
	else{
		echo "Something went wrong1";
	}
?>