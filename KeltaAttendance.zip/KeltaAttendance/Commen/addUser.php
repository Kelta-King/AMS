<?php
//default password of a user will be his/her rollno
session_start();

if(isset($_SESSION['login_user'])){
	$Name = $_REQUEST['firstname']." ".$_REQUEST['lastname'];
	$RollNo = $_REQUEST['RollNo'];
	$acc_type = $_REQUEST['acc_type'];
	$opt = [
		'cost' => 12
	];
	$pass = password_hash($RollNo, PASSWORD_BCRYPT, $opt);
	$query = "INSERT INTO users (RollNo, Name, password, account_type) VALUES ($RollNo, '$Name', '$pass', '$acc_type')";
	
	require_once("../database/dbconnect.php");
		
	if($conn->query($query)){
		echo "New user successfully inserted";
	}
	else{
		echo "something went wrong";
	}
	$conn->close();
}
else{
	echo "something went wrong";
}
	

?>